"""Open-source reasoning trace data ingestion for FMA."""

from .loader import list_available_sources, load_open_traces, normalize_to_internal
from .normalizer import CoTStepParser, annotate_steps_with_taxonomy, classify_step_operation
from .schema import OpenTraceRecord, StepAnnotation

__all__ = [
    "CoTStepParser",
    "OpenTraceRecord",
    "StepAnnotation",
    "annotate_steps_with_taxonomy",
    "classify_step_operation",
    "list_available_sources",
    "load_open_traces",
    "normalize_to_internal",
]
