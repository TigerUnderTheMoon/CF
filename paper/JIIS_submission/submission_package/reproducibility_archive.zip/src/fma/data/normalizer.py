"""CoT step parsing and normalization for free-text reasoning traces."""

from __future__ import annotations

import re

from .schema import StepAnnotation

_TOKEN_RE = re.compile(r"\S+")

_NUMBERED_STEP_RE = re.compile(
    r"(?:^|\n)"
    r"(?P<marker>"
    r"Step\s+\d+\s*[:.)]\s*"
    r"|"
    r"\d+\s*[:.)]\s+"
    r"|"
    r"第[一二三四五六七八九十\d]+步\s*[:：]?\s*"
    r")",
    re.IGNORECASE,
)

_SENTENCE_BOUNDARY_RE = re.compile(r"(?<=[.!?。])\s+(?=[A-Z\u4e00-\u9fff])")

_TRANSITION_CUES = re.compile(
    r"(?:^|\n)\s*"
    r"(?:"
    r"Therefore|Thus|Hence|So[,.]?\s"
    r"|However|But|On the other hand"
    r"|Let(?:'s| us)\s+(?:check|verify|consider|look|think)"
    r"|Wait[,.]?\s"
    r"|Now[,.]?\s+(?:let|we|I)"
    r"|Actually[,.]?\s"
    r"|Alternatively[,.]?\s"
    r")",
    re.IGNORECASE,
)


class CoTStepParser:
    """Parse free-text chain-of-thought into reasoning steps."""

    def __init__(
        self,
        strategy: str = "auto",
        min_step_tokens: int = 3,
        max_merge_tokens: int = 10,
    ) -> None:
        if strategy not in ("auto", "numbered", "sentence", "newline"):
            raise ValueError(f"Unknown parse strategy: {strategy!r}")
        self.strategy = strategy
        self.min_step_tokens = min_step_tokens
        self.max_merge_tokens = max_merge_tokens

    def parse_steps(self, trace: str) -> list[StepAnnotation]:
        if not trace.strip():
            return []

        if self.strategy == "auto":
            raw_steps = self._auto_split(trace)
        elif self.strategy == "numbered":
            raw_steps = self._numbered_split(trace)
        elif self.strategy == "sentence":
            raw_steps = self._sentence_split(trace)
        else:
            raw_steps = self._newline_split(trace)

        merged = self._merge_short_steps(raw_steps, trace)
        return self._annotate_offsets(merged, trace)

    def _auto_split(self, trace: str) -> list[str]:
        if _NUMBERED_STEP_RE.search(trace):
            return self._numbered_split(trace)
        if "\n\n" in trace:
            return self._newline_split(trace)
        return self._sentence_split(trace)

    def _numbered_split(self, trace: str) -> list[str]:
        splits = _NUMBERED_STEP_RE.split(trace)
        steps = []
        for part in splits:
            stripped = part.strip()
            if stripped:
                steps.append(stripped)
        if not steps:
            steps = [trace]
        return steps

    def _newline_split(self, trace: str) -> list[str]:
        paragraphs = re.split(r"\n{2,}", trace)
        steps = []
        for para in paragraphs:
            stripped = para.strip()
            if stripped:
                steps.append(stripped)
        if not steps:
            steps = [line.strip() for line in trace.split("\n") if line.strip()]
        if not steps:
            steps = [trace]
        return steps

    def _sentence_split(self, trace: str) -> list[str]:
        sentences = _SENTENCE_BOUNDARY_RE.split(trace)
        steps = [s.strip() for s in sentences if s.strip()]
        if not steps:
            steps = [trace]
        return steps

    def _merge_short_steps(self, steps: list[str], trace: str) -> list[str]:
        if len(steps) <= 1:
            return steps
        merged: list[str] = []
        buffer = ""
        for step in steps:
            token_count = len(_TOKEN_RE.findall(step))
            if token_count < self.min_step_tokens and not buffer:
                buffer = step
            elif token_count < self.min_step_tokens and buffer:
                buffer_token_count = len(_TOKEN_RE.findall(buffer))
                if buffer_token_count + token_count <= self.max_merge_tokens:
                    buffer = buffer + " " + step
                else:
                    merged.append(buffer)
                    buffer = step
            else:
                if buffer:
                    merged.append(buffer)
                    buffer = ""
                merged.append(step)
        if buffer:
            merged.append(buffer)
        return merged if merged else steps

    def _annotate_offsets(self, steps: list[str], trace: str) -> list[StepAnnotation]:
        annotations: list[StepAnnotation] = []
        char_offset = 0

        for idx, step_text in enumerate(steps):
            if len(step_text) >= 30:
                start_char = trace.find(step_text[:30], char_offset)
            else:
                start_char = trace.find(step_text, char_offset)
            if start_char < 0:
                start_char = trace.find(step_text, max(0, char_offset - 5))
            if start_char < 0:
                start_char = char_offset
            end_char = start_char + len(step_text)

            prefix_tokens = _TOKEN_RE.findall(trace[:start_char])
            content_tokens = _TOKEN_RE.findall(step_text)
            start_token = len(prefix_tokens)
            end_token = start_token + len(content_tokens)

            annotations.append(
                StepAnnotation(
                    step_text=step_text,
                    step_index=idx,
                    start_char=start_char,
                    end_char=end_char,
                    start_token=start_token,
                    end_token=end_token,
                    operation_type="reasoning",
                )
            )
            char_offset = end_char

        return annotations


def classify_step_operation(step_text: str) -> tuple[str, float]:
    """Classify a reasoning step into a metacognitive operation type.

    Reuses the keyword patterns from ``fma.taxonomy.reflection_taxonomy``
    plus additional CoT-specific cues.
    """
    text = step_text.strip().lower()
    if not text:
        return "unknown", 0.0

    verification_cues = (
        "verify", "check", "confirm", "double-check",
        "does this make sense", "let me verify",
    )
    error_correction_cues = (
        "mistake", "error", "incorrect", "wrong",
        "fix", "correct the", "that's not right",
    )
    backtracking_cues = (
        "backtrack", "go back", "try again", "different approach",
        "alternative", "let me reconsider",
    )
    decomposition_cues = (
        "break down", "split", "first.+, then",
        "separate", "subproblem", "divide",
    )
    planning_cues = (
        "plan", "next step", "strategy", "approach",
        "first, i will", "let me think about how",
    )
    uncertainty_cues = (
        "uncertain", "not sure", "might be",
        "could be wrong", "i'm unsure",
    )
    constraint_cues = (
        "constraint", "condition", "must satisfy",
        "requirement", "limit",
    )
    retrieval_cues = (
        "recall", "remember", "we know that",
        "from earlier", "previously",
    )
    cues: dict[str, tuple[str, ...]] = {
        "verification": verification_cues,
        "error_correction": error_correction_cues,
        "backtracking": backtracking_cues,
        "decomposition": decomposition_cues,
        "planning": planning_cues,
        "uncertainty_monitoring": uncertainty_cues,
        "constraint_tracking": constraint_cues,
        "retrieval": retrieval_cues,
    }

    best_type = "reasoning"
    best_score = 0.0

    for op_type, keywords in cues.items():
        score = 0.0
        for kw in keywords:
            if re.search(kw, text, re.IGNORECASE):
                score += 1.0
        if len(keywords) > 0:
            score /= len(keywords)
        if score > best_score:
            best_score = score
            best_type = op_type

    if best_score < 0.15:
        return "reasoning", best_score

    return best_type, min(1.0, best_score)


def annotate_steps_with_taxonomy(steps: list[StepAnnotation]) -> list[StepAnnotation]:
    """Add operation_type classification to steps that lack it."""
    annotated: list[StepAnnotation] = []
    for step in steps:
        if step.operation_type not in ("unknown", "reasoning"):
            annotated.append(step)
            continue
        op_type, confidence = classify_step_operation(step.step_text)
        annotated.append(
            StepAnnotation(
                step_text=step.step_text,
                step_index=step.step_index,
                start_char=step.start_char,
                end_char=step.end_char,
                start_token=step.start_token,
                end_token=step.end_token,
                operation_type=op_type,
                ground_truth_importance=step.ground_truth_importance,
            )
        )
    return annotated


__all__ = ["CoTStepParser", "annotate_steps_with_taxonomy", "classify_step_operation"]
