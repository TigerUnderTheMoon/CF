"""Unified data loader for open-source reasoning traces."""

from __future__ import annotations

from typing import Any

from .normalizer import CoTStepParser, annotate_steps_with_taxonomy
from .schema import OpenTraceRecord
from .sources import SOURCE_REGISTRY
from .sources.gsm8k_cot import load_gsm8k_cot
from .sources.hotpotqa import load_hotpotqa
from .sources.prm800k import load_prm800k
from .sources.process_bench import load_process_bench

_SOURCE_LOADERS: dict[str, Any] = {
    "prm800k": load_prm800k,
    "gsm8k_cot": load_gsm8k_cot,
    "hotpotqa": load_hotpotqa,
    "process_bench": load_process_bench,
}


def list_available_sources() -> dict[str, str]:
    """Return registered data sources with descriptions."""
    return dict(SOURCE_REGISTRY)


def load_open_traces(
    source: str,
    split: str = "test",
    max_samples: int = -1,
    models: list[str] | None = None,
    correct_only: bool = False,
    trace_dir: str | None = None,
    classify_operations: bool = True,
    parse_strategy: str = "auto",
) -> list[OpenTraceRecord]:
    """Load reasoning traces from an open-source data source.

    Args:
        source: Data source identifier (see ``list_available_sources()``).
        split: Dataset split to load.
        max_samples: Maximum number of records; -1 for unlimited.
        models: Optional model name filter.
        correct_only: If True, only load traces with correct final answers.
        trace_dir: For gsm8k_cot, directory of pre-generated JSONL traces.
        classify_operations: If True, classify each step's operation type.
        parse_strategy: CoT parsing strategy ("auto", "numbered", "sentence", "newline").

    Returns:
        List of ``OpenTraceRecord`` instances.
    """
    if source not in _SOURCE_LOADERS:
        available = ", ".join(sorted(_SOURCE_LOADERS))
        raise ValueError(f"Unknown source {source!r}. Available: {available}")

    loader = _SOURCE_LOADERS[source]
    kwargs: dict[str, Any] = {
        "split": split,
        "max_samples": max_samples,
        "models": models,
        "correct_only": correct_only,
    }
    if source in ("gsm8k_cot", "hotpotqa"):
        kwargs["trace_dir"] = trace_dir

    records = loader(**kwargs)

    if classify_operations:
        parser = CoTStepParser(strategy=parse_strategy)
        records = _reparse_with_classification(records, parser)

    return records


def _reparse_with_classification(
    records: list[OpenTraceRecord],
    parser: CoTStepParser,
) -> list[OpenTraceRecord]:
    reclassified: list[OpenTraceRecord] = []
    for record in records:
        if not record.step_annotations:
            parsed = parser.parse_steps(record.full_reasoning_trace)
            annotated = annotate_steps_with_taxonomy(parsed)
            reclassified.append(
                OpenTraceRecord(
                    sample_id=record.sample_id,
                    question=record.question,
                    full_reasoning_trace=record.full_reasoning_trace,
                    answer=record.answer,
                    reference_answer=record.reference_answer,
                    model_name=record.model_name,
                    dataset=record.dataset,
                    is_correct=record.is_correct,
                    step_annotations=tuple(annotated),
                    metadata=record.metadata,
                )
            )
        else:
            annotated = annotate_steps_with_taxonomy(list(record.step_annotations))
            reclassified.append(
                OpenTraceRecord(
                    sample_id=record.sample_id,
                    question=record.question,
                    full_reasoning_trace=record.full_reasoning_trace,
                    answer=record.answer,
                    reference_answer=record.reference_answer,
                    model_name=record.model_name,
                    dataset=record.dataset,
                    is_correct=record.is_correct,
                    step_annotations=tuple(annotated),
                    metadata=record.metadata,
                )
            )
    return reclassified


def normalize_to_internal(records: list[OpenTraceRecord]) -> list[dict[str, Any]]:
    """Convert open trace records to the internal JSONL format.

    The output format is compatible with ``fma.ciu.estimator`` and
    ``fma.attribution.engine`` pipelines.
    """
    return [record.to_internal_record() for record in records]


__all__ = [
    "SOURCE_REGISTRY",
    "list_available_sources",
    "load_open_traces",
    "normalize_to_internal",
]
