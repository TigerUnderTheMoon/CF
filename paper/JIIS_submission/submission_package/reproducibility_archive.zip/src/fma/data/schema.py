"""Unified input schema for open-source reasoning traces."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class StepAnnotation:
    step_text: str
    step_index: int
    start_char: int
    end_char: int
    start_token: int
    end_token: int
    operation_type: str = "unknown"
    ground_truth_importance: float | None = None


@dataclass(frozen=True)
class OpenTraceRecord:
    sample_id: str
    question: str
    full_reasoning_trace: str
    answer: str
    reference_answer: str
    model_name: str
    dataset: str
    is_correct: bool
    step_annotations: tuple[StepAnnotation, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_internal_record(self) -> dict[str, Any]:
        spans = []
        for ann in self.step_annotations:
            spans.append(
                {
                    "span_index": ann.step_index,
                    "start_char": ann.start_char,
                    "end_char": ann.end_char,
                    "start_token": ann.start_token,
                    "end_token": ann.end_token,
                    "operation_type": ann.operation_type,
                    "content": ann.step_text,
                }
            )
        return {
            "sample_id": self.sample_id,
            "question": self.question,
            "reasoning_trace": self.full_reasoning_trace,
            "final_answer": self.answer,
            "reference_answer": self.reference_answer,
            "correctness": self.is_correct,
            "task_type": self.dataset,
            "model_name": self.model_name,
            "reflection_spans": spans,
            "synthetic": False,
            "metadata": self.metadata,
        }
