"""Load GSM8K multi-model chain-of-thought traces."""

from __future__ import annotations

import hashlib
import re
from typing import Any

from ..schema import OpenTraceRecord, StepAnnotation

GSM8K_MODEL_SOURCES: dict[str, dict[str, str]] = {
    "deepseek-r1": {
        "description": "DeepSeek-R1 distilled or full reasoning traces on GSM8K",
    },
    "qwq": {
        "description": "QwQ-32B reasoning traces on GSM8K",
    },
    "o1-mini": {
        "description": "OpenAI o1-mini reasoning traces on GSM8K",
    },
}


def load_gsm8k_cot(
    split: str = "test",
    max_samples: int = -1,
    models: list[str] | None = None,
    correct_only: bool = False,
    trace_dir: str | None = None,
) -> list[OpenTraceRecord]:
    """Load GSM8K reasoning traces.

    Strategy:
    1. If ``trace_dir`` is provided, load pre-generated JSONL traces from disk.
    2. Otherwise, fall back to loading the base GSM8K dataset and treating
       the ``answer`` field as a single-step trace (limited utility).

    For multi-model traces, pre-generate them via an external script
    that calls the respective APIs and saves JSONL files to ``trace_dir``.
    """
    if trace_dir is not None:
        return _load_from_trace_dir(trace_dir, max_samples, models, correct_only)

    return _load_from_huggingface(split, max_samples, correct_only)


def _load_from_huggingface(
    split: str,
    max_samples: int,
    correct_only: bool,
) -> list[OpenTraceRecord]:
    try:
        from datasets import load_dataset
    except ImportError as exc:
        raise ImportError("Install the 'ml' extra: poetry install -E ml") from exc

    ds = load_dataset("openai/gsm8k", "main", split=split, trust_remote_code=False)
    records: list[OpenTraceRecord] = []

    for row in ds:
        question = str(row.get("question", ""))
        answer_field = str(row.get("answer", ""))
        trace_text, reference = _split_gsm8k_answer(answer_field)

        if not trace_text or not question:
            continue

        is_correct = _check_gsm8k_correctness(trace_text, reference)
        if correct_only and not is_correct:
            continue

        steps = _split_into_steps(trace_text)
        sample_id = _make_sample_id("gsm8k", question, split)

        records.append(
            OpenTraceRecord(
                sample_id=sample_id,
                question=question,
                full_reasoning_trace=trace_text,
                answer=reference,
                reference_answer=reference,
                model_name="gsm8k_original",
                dataset="gsm8k",
                is_correct=is_correct,
                step_annotations=tuple(steps),
                metadata={"source": "gsm8k/main", "split": split},
            )
        )
        if 0 < max_samples <= len(records):
            break

    return records


def _load_from_trace_dir(
    trace_dir: str,
    max_samples: int,
    models: list[str] | None,
    correct_only: bool,
) -> list[OpenTraceRecord]:
    import json
    from pathlib import Path

    dir_path = Path(trace_dir)
    if not dir_path.is_dir():
        raise FileNotFoundError(f"Trace directory not found: {trace_dir}")

    records: list[OpenTraceRecord] = []
    model_filter = set(models) if models else None

    for jsonl_path in sorted(dir_path.glob("*.jsonl")):
        with jsonl_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    row = json.loads(stripped)
                except json.JSONDecodeError:
                    continue
                if not isinstance(row, dict):
                    continue

                model_name = str(row.get("model_name", "unknown"))
                if model_filter and model_name not in model_filter:
                    continue

                is_correct = bool(row.get("is_correct", row.get("correctness", False)))
                if correct_only and not is_correct:
                    continue

                trace_text = str(
                    row.get("full_reasoning_trace")
                    or row.get("reasoning_trace")
                    or ""
                )
                question = str(row.get("question", ""))
                answer = str(row.get("answer", row.get("final_answer", "")))
                reference = str(row.get("reference_answer", answer))
                dataset = str(row.get("dataset", "gsm8k"))
                sample_id = str(
                    row.get(
                        "sample_id",
                        _make_sample_id("gsm8k_cot", question, "test"),
                    )
                )

                steps = _parse_pre_annotated_steps(row, trace_text)
                if not steps:
                    steps = _split_into_steps(trace_text)

                records.append(
                    OpenTraceRecord(
                        sample_id=sample_id,
                        question=question,
                        full_reasoning_trace=trace_text,
                        answer=answer,
                        reference_answer=reference,
                        model_name=model_name,
                        dataset=dataset,
                        is_correct=is_correct,
                        step_annotations=tuple(steps),
                        metadata=row.get("metadata", {}),
                    )
                )
                if 0 < max_samples <= len(records):
                    break
        if 0 < max_samples <= len(records):
            break

    return records


def _split_gsm8k_answer(answer_field: str) -> tuple[str, str]:
    parts = answer_field.split("####")
    trace = parts[0].strip() if parts else answer_field
    reference = parts[1].strip() if len(parts) > 1 else ""
    return trace, reference


def _check_gsm8k_correctness(trace_text: str, reference: str) -> bool:
    ref_nums = re.findall(r"[-+]?\d[\d,]*(?:\.\d+)?", reference)
    if not ref_nums:
        return False
    ref_num = ref_nums[-1].replace(",", "")
    trace_nums = re.findall(r"[-+]?\d[\d,]*(?:\.\d+)?", trace_text)
    if not trace_nums:
        return False
    last_trace_num = trace_nums[-1].replace(",", "")
    return ref_num == last_trace_num


_TOKEN_RE = re.compile(r"\S+")
_STEP_SPLIT_RE = re.compile(r"(?:\n{2,}|\n(?=Step\s+\d)|\n(?=\d+\.\s))", re.IGNORECASE)


def _split_into_steps(trace_text: str) -> list[StepAnnotation]:
    raw_steps = _STEP_SPLIT_RE.split(trace_text)
    if len(raw_steps) <= 1:
        raw_steps = [s.strip() for s in trace_text.split("\n") if s.strip()]
        if not raw_steps:
            raw_steps = [trace_text]

    annotations: list[StepAnnotation] = []
    char_offset = 0

    for idx, step_text in enumerate(raw_steps):
        step_text = step_text.strip()
        if not step_text:
            continue

        start_char = trace_text.find(step_text, char_offset)
        if start_char < 0:
            start_char = char_offset
        end_char = start_char + len(step_text)

        prefix_tokens = _TOKEN_RE.findall(trace_text[:start_char])
        content_tokens = _TOKEN_RE.findall(step_text)
        start_token = len(prefix_tokens)
        end_token = start_token + len(content_tokens)

        annotations.append(
            StepAnnotation(
                step_text=step_text,
                step_index=idx,
                start_char=start_char,
                end_char=end_char,
                start_token=start_token,
                end_token=end_token,
                operation_type="reasoning",
            )
        )
        char_offset = end_char

    return annotations


def _parse_pre_annotated_steps(row: dict[str, Any], trace_text: str) -> list[StepAnnotation]:
    spans = row.get("step_annotations") or row.get("reflection_spans") or []
    if not isinstance(spans, list):
        return []

    annotations: list[StepAnnotation] = []
    for idx, span in enumerate(spans):
        if not isinstance(span, dict):
            continue
        annotations.append(
            StepAnnotation(
                step_text=str(span.get("content") or span.get("step_text", "")),
                step_index=int(span.get("step_index", span.get("span_index", idx))),
                start_char=int(span.get("start_char", 0)),
                end_char=int(span.get("end_char", 0)),
                start_token=int(span.get("start_token", 0)),
                end_token=int(span.get("end_token", 0)),
                operation_type=str(span.get("operation_type", "reasoning")),
                ground_truth_importance=span.get("ground_truth_importance"),
            )
        )
    return annotations


def _make_sample_id(prefix: str, question: str, split: str) -> str:
    digest = hashlib.sha256(question.encode("utf-8")).hexdigest()[:12]
    return f"{prefix}_{split}_{digest}"


__all__ = ["GSM8K_MODEL_SOURCES", "load_gsm8k_cot"]
