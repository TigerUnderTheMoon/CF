"""Load ProcessBench process supervision data."""

from __future__ import annotations

import hashlib
from typing import Any

from ..schema import OpenTraceRecord, StepAnnotation


def load_process_bench(
    split: str = "test",
    max_samples: int = -1,
    models: list[str] | None = None,
    correct_only: bool = False,
) -> list[OpenTraceRecord]:
    """Load ProcessBench from HuggingFace.

    ProcessBench provides multi-domain math and reasoning problems with
    step-level correctness annotations from multiple models.
    """
    try:
        from datasets import load_dataset
    except ImportError as exc:
        raise ImportError("Install the 'ml' extra: poetry install -E ml") from exc

    ds = load_dataset("Qwen/ProcessBench", split=split, trust_remote_code=False)
    records: list[OpenTraceRecord] = []

    for row in ds:
        question = str(row.get("question", row.get("problem", "")))
        trace_text = str(row.get("solution", row.get("reasoning", "")))
        answer = str(row.get("answer", ""))
        reference = str(row.get("reference_answer", answer))

        if not trace_text or not question:
            continue

        is_correct = bool(row.get("is_correct", row.get("correct", True)))
        if correct_only and not is_correct:
            continue

        model_name = str(row.get("model", row.get("model_name", "unknown")))
        if models and model_name not in models:
            continue

        steps = _parse_process_bench_steps(row, trace_text)
        sample_id = _make_sample_id("processbench", question, split)
        dataset_name = str(row.get("dataset", row.get("source", "process_bench")))

        records.append(
            OpenTraceRecord(
                sample_id=sample_id,
                question=question,
                full_reasoning_trace=trace_text,
                answer=answer,
                reference_answer=reference,
                model_name=model_name,
                dataset=dataset_name,
                is_correct=is_correct,
                step_annotations=tuple(steps),
                metadata={"source": "processbench", "split": split},
            )
        )
        if 0 < max_samples <= len(records):
            break

    return records


def _parse_process_bench_steps(row: dict[str, Any], trace_text: str) -> list[StepAnnotation]:

    step_labels = row.get("step_labels") or row.get("process_label") or []
    steps_text = row.get("steps") or row.get("step_texts") or []

    if isinstance(steps_text, list) and steps_text:
        return _annotate_explicit_steps(steps_text, step_labels, trace_text)

    return _split_by_newlines(trace_text, step_labels)


def _annotate_explicit_steps(
    steps_text: list[Any],
    step_labels: list[Any],
    trace_text: str,
) -> list[StepAnnotation]:
    import re

    token_re = re.compile(r"\S+")
    annotations: list[StepAnnotation] = []
    char_offset = 0

    for idx, step in enumerate(steps_text):
        text = str(step).strip()
        if not text:
            continue

        start_char = trace_text.find(text, char_offset)
        if start_char < 0:
            start_char = char_offset
        end_char = start_char + len(text)

        prefix_tokens = token_re.findall(trace_text[:start_char])
        content_tokens = token_re.findall(text)
        start_token = len(prefix_tokens)
        end_token = start_token + len(content_tokens)

        importance = None
        if idx < len(step_labels):
            label = step_labels[idx]
            if isinstance(label, bool):
                importance = 1.0 if label else 0.0
            elif isinstance(label, (int, float)):
                importance = float(label)

        annotations.append(
            StepAnnotation(
                step_text=text,
                step_index=idx,
                start_char=start_char,
                end_char=end_char,
                start_token=start_token,
                end_token=end_token,
                operation_type="reasoning",
                ground_truth_importance=importance,
            )
        )
        char_offset = end_char

    return annotations


def _split_by_newlines(trace_text: str, step_labels: list[Any]) -> list[StepAnnotation]:
    import re

    token_re = re.compile(r"\S+")
    lines = [line.strip() for line in trace_text.split("\n") if line.strip()]
    annotations: list[StepAnnotation] = []
    char_offset = 0

    for idx, line in enumerate(lines):
        start_char = trace_text.find(line, char_offset)
        if start_char < 0:
            start_char = char_offset
        end_char = start_char + len(line)

        prefix_tokens = token_re.findall(trace_text[:start_char])
        content_tokens = token_re.findall(line)
        start_token = len(prefix_tokens)
        end_token = start_token + len(content_tokens)

        importance = None
        if idx < len(step_labels):
            label = step_labels[idx]
            if isinstance(label, bool):
                importance = 1.0 if label else 0.0
            elif isinstance(label, (int, float)):
                importance = float(label)

        annotations.append(
            StepAnnotation(
                step_text=line,
                step_index=idx,
                start_char=start_char,
                end_char=end_char,
                start_token=start_token,
                end_token=end_token,
                operation_type="reasoning",
                ground_truth_importance=importance,
            )
        )
        char_offset = end_char

    return annotations


def _make_sample_id(prefix: str, question: str, split: str) -> str:
    digest = hashlib.sha256(question.encode("utf-8")).hexdigest()[:12]
    return f"{prefix}_{split}_{digest}"


__all__ = ["load_process_bench"]
