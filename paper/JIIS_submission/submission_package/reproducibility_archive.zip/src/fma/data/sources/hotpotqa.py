"""Load HotpotQA data from local JSONL files."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from ..schema import OpenTraceRecord, StepAnnotation

_PILOT_PATH = Path("data/real_task_pilot/hotpotqa_validation.jsonl")


def load_hotpotqa(
    split: str = "validation",
    max_samples: int = -1,
    models: list[str] | None = None,
    correct_only: bool = False,
    trace_dir: str | None = None,
) -> list[OpenTraceRecord]:
    """Load HotpotQA questions and reference answers from local JSONL.

    If ``trace_dir`` is provided, load pre-generated reasoning traces
    from that directory (produced by ``generate_hotpotqa_traces.py``).

    Otherwise, loads question/answer pairs only (no CoT steps).
    """
    source_path = _find_source_path(split)
    if not source_path.exists():
        raise FileNotFoundError(f"HotpotQA source not found: {source_path}")

    raw_records = _load_jsonl(source_path, max_samples)

    if trace_dir is not None:
        return _load_with_traces(raw_records, trace_dir, max_samples, models)

    return _load_bare_questions(raw_records, max_samples)


def _find_source_path(split: str) -> Path:
    candidates = [
        Path(f"data/real_task_pilot/hotpotqa_{split}.jsonl"),
        Path(f"data/real_task_v3/hotpotqa_distractor_{split}_declared.jsonl"),
        Path("data/real_task_v3/hotpotqa_distractor_train_declared.jsonl"),
        _PILOT_PATH,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return _PILOT_PATH


def _load_jsonl(path: Path, max_samples: int) -> list[dict[str, Any]]:
    import json

    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue
            if 0 < max_samples <= len(records):
                break
    return records


def _load_bare_questions(
    raw_records: list[dict[str, Any]],
    max_samples: int,
) -> list[OpenTraceRecord]:
    """Load question-only records (no CoT). Used as placeholder before trace generation."""
    records: list[OpenTraceRecord] = []
    for row in raw_records:
        question = str(row.get("question", ""))
        answer = str(row.get("reference_answer", ""))
        aliases = row.get("aliases", [])
        sample_id = str(
            row.get("task_id")
            or row.get("sample_id")
            or _make_sample_id("hotpotqa", question)
        )

        records.append(
            OpenTraceRecord(
                sample_id=sample_id,
                question=question,
                full_reasoning_trace="",
                answer=answer,
                reference_answer=answer,
                model_name="no_trace",
                dataset="hotpotqa",
                is_correct=False,
                step_annotations=(),
                metadata={
                    "aliases": aliases if isinstance(aliases, list) else [],
                    "source": "hotpotqa/" + str(row.get("source_split", "validation")),
                },
            )
        )
        if 0 < max_samples <= len(records):
            break
    return records


def _load_with_traces(
    raw_records: list[dict[str, Any]],
    trace_dir: str,
    max_samples: int,
    models: list[str] | None,
) -> list[OpenTraceRecord]:
    """Load generated traces from JSONL files in trace_dir."""
    import json
    from pathlib import Path

    dir_path = Path(trace_dir)
    trace_by_q: dict[str, dict[str, Any]] = {}
    for jsonl_path in sorted(dir_path.glob("*.jsonl")):
        with jsonl_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                q = str(row.get("question", ""))
                trace_by_q[q] = row

    records: list[OpenTraceRecord] = []
    for row in raw_records:
        question = str(row.get("question", ""))
        trace_row = trace_by_q.get(question)
        if trace_row is None:
            continue

        trace_text = str(
            trace_row.get("observable_trace") or trace_row.get("reasoning_trace") or ""
        )
        final_answer = str(
            trace_row.get("final_answer")
            or trace_row.get("answer")
            or row.get("reference_answer", "")
        )
        reference = str(row.get("reference_answer", ""))
        aliases = row.get("aliases", [])
        sample_id = str(
            row.get("task_id") or row.get("sample_id") or _make_sample_id("hotpotqa", question)
        )

        model_name = str(trace_row.get("model_name", "deepseek-v4"))
        if models and model_name not in models:
            continue

        from fma.real_task_pilot.parsing import extract_reflection_spans

        spans_raw = extract_reflection_spans(trace_text) if trace_text else []
        steps: list[StepAnnotation] = []
        for idx, span in enumerate(spans_raw):
            steps.append(
                StepAnnotation(
                    step_text=str(span.get("content", "")),
                    step_index=idx,
                    start_char=int(span.get("start_char", 0)),
                    end_char=int(span.get("end_char", 0)),
                    start_token=int(span.get("start_token", 0)),
                    end_token=int(span.get("end_token", 0)),
                    operation_type=str(span.get("operation_type", "reasoning")),
                )
            )
        if not steps and trace_text:
            from fma.data.normalizer import CoTStepParser, annotate_steps_with_taxonomy

            parser = CoTStepParser(strategy="newline")
            steps = annotate_steps_with_taxonomy(parser.parse_steps(trace_text))

        is_correct = _check_correctness_via_aliases(final_answer, reference, aliases)
        if not is_correct and trace_text:
            last_line = trace_text.strip().split("\n")[-1]
            is_correct = _check_via_last_line(last_line, reference, aliases)

        records.append(
            OpenTraceRecord(
                sample_id=sample_id,
                question=question,
                full_reasoning_trace=trace_text,
                answer=final_answer,
                reference_answer=reference,
                model_name=model_name,
                dataset="hotpotqa",
                is_correct=is_correct,
                step_annotations=tuple(steps),
                metadata={
                    "aliases": aliases if isinstance(aliases, list) else [],
                    "source": "hotpotqa/" + str(row.get("source_split", "validation")),
                },
            )
        )
        if 0 < max_samples <= len(records):
            break

    return records


def _check_correctness_via_aliases(
    predicted: str,
    reference: str,
    aliases: list[str],
) -> bool:
    from fma.eval.answer_match import normalize_answer

    pred = normalize_answer(predicted)
    ref = normalize_answer(reference)
    if pred == ref:
        return True
    for alias in aliases:
        if normalize_answer(alias) == pred:
            return True
    return False


def _check_via_last_line(
    last_line: str,
    reference: str,
    aliases: list[str],
) -> bool:
    last_line = last_line.strip().lower()
    if reference.lower() in last_line:
        return True
    for alias in aliases:
        if alias.lower() in last_line:
            return True
    return False


def _make_sample_id(prefix: str, question: str) -> str:
    digest = hashlib.sha256(question.encode("utf-8")).hexdigest()[:12]
    return f"{prefix}_{digest}"


__all__ = ["load_hotpotqa"]
