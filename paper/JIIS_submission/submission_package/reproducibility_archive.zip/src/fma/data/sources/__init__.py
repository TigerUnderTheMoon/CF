"""Open-source reasoning trace data sources."""

from __future__ import annotations

from .gsm8k_cot import load_gsm8k_cot
from .hotpotqa import load_hotpotqa
from .prm800k import load_prm800k
from .process_bench import load_process_bench

SOURCE_REGISTRY: dict[str, str] = {
    "prm800k": "openai/prm800k step-level labeled traces (gated)",
    "gsm8k_cot": "GSM8K multi-model chain-of-thought traces",
    "hotpotqa": "HotpotQA multi-hop QA (local JSONL + generated traces)",
    "process_bench": "ProcessBench process supervision data",
}

__all__ = [
    "SOURCE_REGISTRY",
    "load_gsm8k_cot",
    "load_prm800k",
    "load_process_bench",
]
