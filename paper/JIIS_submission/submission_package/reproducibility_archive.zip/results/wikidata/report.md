# Wikidata Scientist KG Controlled Knowledge-Maintenance Experiment

This experiment validates the proposed audit representation under controlled knowledge-maintenance scenarios on a real KG substrate, rather than evaluating native Wikidata structural roles.

Substrate: corrected_multidisciplinary_v2; same as V1=False. Correction: V1 seed selection yielded 300 physical-science scientists and no other discipline groups.

## Controlled Audit Role Evaluation

Evaluation is performed against controlled audit motifs rather than native Wikidata annotations.

- Bottleneck F1: 1.000
- Redundancy F1: 1.000
- Macro F1: 1.000

## Graph Statistics

| Nodes | Edges | Average degree | Weak components | Diameter | Average path length |
|---:|---:|---:|---:|---:|---:|
| 2000 | 6039 | 6.039 | 1 | 9 | 4.189 |

## Impact Coverage@K Summary

| Dataset | Method | K | Impact Coverage | Mean covered-path length |
|---|---|---:|---:|---:|
| Countries-KG diagnostic fixture | Life-Saving First | 25% | 0.733 | 0.828 |
| Countries-KG diagnostic fixture | Flat Top-K | 25% | 0.733 | 0.828 |
| Countries-KG diagnostic fixture | Degree | 25% | 0.650 | 0.761 |
| Countries-KG diagnostic fixture | Random Stratified | 25% | 0.733 | 0.828 |
| Countries-KG diagnostic fixture | Position | 25% | 0.000 | 0.000 |
| Countries-KG diagnostic fixture | Random | 25% | 0.364 | 0.593 |
| Countries-KG diagnostic fixture | No-Fallback | 25% | 0.733 | 0.878 |
| Wikidata scientist KG | Degree | 25% | 0.473 | 1.220 |
| Wikidata scientist KG | Flat Top-K | 25% | 0.495 | 1.245 |
| Wikidata scientist KG | Greedy Maximum Coverage | 25% | 0.633 | 1.198 |
| Wikidata scientist KG | LSF-Clustered | 25% | 0.585 | 1.198 |
| Wikidata scientist KG | Life-Saving First | 25% | 0.584 | 1.198 |
| Wikidata scientist KG | LSF minus bottleneck | 25% | 0.531 | 1.213 |
| Wikidata scientist KG | LSF minus redundancy | 25% | 0.584 | 1.198 |
| Wikidata scientist KG | LSF minus unique layer | 25% | 0.584 | 1.198 |
| Wikidata scientist KG | Position | 25% | 0.107 | 1.000 |
| Wikidata scientist KG | Random | 25% | 0.260 | 1.091 |
| Wikidata scientist KG | Random Stratified | 25% | 0.341 | 1.097 |

## Anchor-Cluster Confirmation

The predeclared K=5% confirmation uses 16 anchor clusters from one Wikidata substrate as paired statistical units; they are not independent knowledge graphs.

| Method | Impact Coverage mean | SD | Units |
|---|---:|---:|---:|
| Life-Saving First | 0.5313 | 0.0763 | 16 |
| Greedy Maximum Coverage | 0.5546 | 0.0602 | 16 |
| Flat Top-K | 0.5172 | 0.0928 | 16 |
| Degree | 0.4371 | 0.1271 | 16 |

## Revision-History Case Studies

No verified cases were available. Error: offline_mode: revision-history cases not fetched
## Evidence Boundary

This is a controlled knowledge-maintenance experiment on a real KG substrate. It does not establish deployed effectiveness, human curator usefulness, native Wikidata role annotations, or causal identification.
