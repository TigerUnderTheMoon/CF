# JIIS fair-v1 frozen reproduction archive

This archive contains only the frozen Countries-KG cache and the corrected Wikidata v2 substrate used by the paper. It does not download new data or provide external-validity evidence.

Offline reproduction:

1. `python -m pip install -r requirements-jiis-lock.txt`
2. `python scripts/run_wikidata_scientist_audit.py --config configs/jiis_controlled_maintenance_fair_v1.yaml`

The configuration sets `offline: true`; a missing or mismatched cache fails before any network request. Compare the rebuilt JSON metrics under `reproduced_outputs/jiis_controlled_maintenance_fair_v1` with `results/wikidata`.
